(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_b56497ed._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_b56497ed._.js",
  "chunks": [
    "static/chunks/src_3e6896ff._.js",
    "static/chunks/node_modules_next_bfa10154._.js",
    "static/chunks/node_modules_micromark-core-commonmark_dev_lib_36a4b45d._.js",
    "static/chunks/node_modules_314a50f6._.js"
  ],
  "source": "dynamic"
});
