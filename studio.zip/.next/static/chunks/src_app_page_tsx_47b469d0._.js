(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_47b469d0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_47b469d0._.js",
  "chunks": [
    "static/chunks/src_35aa9f8e._.js",
    "static/chunks/node_modules_2dbefcff._.js"
  ],
  "source": "dynamic"
});
