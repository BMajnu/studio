(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_bfa4278d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_bfa4278d._.js",
  "chunks": [
    "static/chunks/src_7c17b2ad._.js",
    "static/chunks/node_modules_337ade2f._.js"
  ],
  "source": "dynamic"
});
