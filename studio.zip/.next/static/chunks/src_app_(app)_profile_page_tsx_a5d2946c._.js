(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(app)_profile_page_tsx_a5d2946c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(app)_profile_page_tsx_a5d2946c._.js",
  "chunks": [
    "static/chunks/src_81b06ee7._.js",
    "static/chunks/node_modules_e82c1731._.js"
  ],
  "source": "dynamic"
});
