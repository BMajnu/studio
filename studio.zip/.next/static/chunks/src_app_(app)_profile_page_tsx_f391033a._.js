(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(app)_profile_page_tsx_f391033a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(app)_profile_page_tsx_f391033a._.js",
  "chunks": [
    "static/chunks/src_3ce185f5._.js",
    "static/chunks/node_modules_5b3027c2._.js"
  ],
  "source": "dynamic"
});
